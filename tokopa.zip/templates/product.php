<div class="content page-content product">
  <h1 class="optimus"><?php the_title() ?></h1>
  <?php the_content() ?>
</div><!-- /.blog-post -->
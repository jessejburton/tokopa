<div class="content">
  <?php the_content(); ?>
</div><!-- /.blog-post -->
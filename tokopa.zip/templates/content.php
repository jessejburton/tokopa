<div class="content page-content">
  <?php the_content(); ?>
</div><!-- /.blog-post -->
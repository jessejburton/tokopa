<?php
/**
 * Single Product Price
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/price.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @author  WooThemes
 * @package WooCommerce/Templates
 * @version 3.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $product;

?>
<p class="price jesse"><?php echo $product->get_price_html(); ?> </p>

<!-- Adding an if so that the currency selector only shows up for the book 
    Removed the currency switcher to test out a price by country option
-->
<?php /*if( $product->get_id() == 7811){ ?>
	<p class="currency-switch"><?php echo do_shortcode( '[wcj_currency_select_link_list]' ); ?></p>
<?php } */?>

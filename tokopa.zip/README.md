# README #

WordPress theme created for the Salt Spring Centre of Yoga

### What is this repository for? ###

* Custom WordPress theme created for the Salt Spring Centre of Yoga based on a style guide created by Marianne Butler
* Version 1.0

### Who do I talk to? ###

* Theme created by Jesse Burton of Burton Media
* www.burtonmediainc.com
* jesse@burtonmediainc.com